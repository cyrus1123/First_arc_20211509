MCMC
====

.. include:: pyro.infer.mcmc.txt
